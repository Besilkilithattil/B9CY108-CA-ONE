"""TCP library registration server backed by MongoDB."""

import argparse
import json
import socketserver
import uuid
from datetime import datetime, timezone
from pymongo import ASCENDING, MongoClient
from pymongo.errors import PyMongoError

MAX_MESSAGE_BYTES = 8192
DATABASE = "library_registration_ca_one"
COLLECTION = "members"


def validate_member(data):
    if not isinstance(data, dict):
        raise ValueError("Registration must be a JSON object.")
    fields = ("full_name", "residential_address", "contact_number", "email")
    member = {}
    for field in fields:
        value = data.get(field)
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{field} is required.")
        member[field] = value.strip()
    if "@" not in member["email"] or "." not in member["email"].split("@")[-1]:
        raise ValueError("A valid-looking email address is required.")
    duration = data.get("membership_months")
    if type(duration) is not int or duration not in (6, 12):
        raise ValueError("Membership must be 6 or 12 months.")
    member["membership_months"] = duration
    member["registration_number"] = "LIB-" + uuid.uuid4().hex[:16].upper()
    member["registered_at_utc"] = datetime.now(timezone.utc).isoformat()
    return member


def save_to_mongodb(member, mongo_uri):
    with MongoClient(mongo_uri, serverSelectionTimeoutMS=5000) as client:
        collection = client[DATABASE][COLLECTION]
        collection.create_index([("registration_number", ASCENDING)], unique=True)
        collection.insert_one(member)


class RegistrationHandler(socketserver.StreamRequestHandler):
    def handle(self):
        print(f"TCP connection established with {self.client_address[0]}:{self.client_address[1]}", flush=True)
        try:
            raw = self.rfile.readline(MAX_MESSAGE_BYTES + 1)
            if not raw or len(raw) > MAX_MESSAGE_BYTES or not raw.endswith(b"\n"):
                raise ValueError("A newline-terminated JSON request under 8 KB is required.")
            data = json.loads(raw.decode("utf-8"))
            member = validate_member(data)
            save_to_mongodb(member, self.server.mongo_uri)
            print(
                f"Stored {member['full_name']} in MongoDB; registration {member['registration_number']}",
                flush=True,
            )
            reply = {"ok": True, "registration_number": member["registration_number"]}
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as error:
            reply = {"ok": False, "error": str(error)}
        except (PyMongoError, OSError) as error:
            print(f"Database error: {error}", flush=True)
            reply = {"ok": False, "error": "The database could not store this registration."}
        self.wfile.write((json.dumps(reply) + "\n").encode("utf-8"))


class RegistrationServer(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def main():
    parser = argparse.ArgumentParser(description="Run the TCP library registration server.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5055)
    parser.add_argument("--mongo-uri", default="mongodb://127.0.0.1:27017")
    args = parser.parse_args()
    with RegistrationServer((args.host, args.port), RegistrationHandler) as server:
        server.mongo_uri = args.mongo_uri
        print(f"Listening for TCP registrations on {args.host}:{args.port}", flush=True)
        server.serve_forever()


if __name__ == "__main__":
    main()
