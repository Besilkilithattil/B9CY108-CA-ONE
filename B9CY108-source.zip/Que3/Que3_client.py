"""Console client for the TCP library registration server."""

import argparse
import json
import socket


def required(prompt):
    while True:
        value = input(prompt).strip()
        if value:
            return value
        print("This field cannot be blank.")


def membership_duration():
    while True:
        value = input("Membership duration (6 or 12 months): ").strip()
        if value in ("6", "12"):
            return int(value)
        print("Please enter 6 or 12.")


def main():
    parser = argparse.ArgumentParser(description="Register for the online library.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5055)
    args = parser.parse_args()

    data = {
        "full_name": required("Full name: "),
        "residential_address": required("Residential address: "),
        "contact_number": required("Contact number: "),
        "email": required("Email address: "),
        "membership_months": membership_duration(),
    }
    try:
        with socket.create_connection((args.host, args.port), timeout=10) as connection:
            print(f"Connected to TCP server at {args.host}:{args.port}")
            connection.sendall((json.dumps(data) + "\n").encode("utf-8"))
            print("Registration details sent to server.")
            response = connection.makefile("r", encoding="utf-8").readline()
        if not response:
            raise ConnectionError("The server closed the connection without a reply.")
        reply = json.loads(response)
        if reply.get("ok"):
            print(f"Registration successful. Your number is {reply['registration_number']}")
        else:
            print(f"Registration failed: {reply.get('error', 'Unknown server error')}")
    except (OSError, ConnectionError, json.JSONDecodeError) as error:
        print(f"Connection error: {error}")


if __name__ == "__main__":
    main()
