using StaffManagement;

var directory = new StaffDirectory();
Assert(!directory.SearchStaff("D001"), "An empty directory must return false.");

directory.Add(new Doctor("Asha Byrne", "D001", "Cardiology", "Cardiology"));
Assert(directory.SearchStaff("D001"), "An existing ID must return true.");
Assert(directory.SearchStaff("d001"), "Search should ignore ID letter case.");
Assert(!directory.SearchStaff("N999"), "An unknown ID must return false.");

Console.WriteLine("PASS: SearchStaff returns false for an empty directory.");
Console.WriteLine("PASS: SearchStaff returns true for an existing ID.");
Console.WriteLine("PASS: SearchStaff ignores ID letter case.");
Console.WriteLine("PASS: SearchStaff returns false for an unknown ID.");

static void Assert(bool condition, string message)
{
    if (!condition) throw new Exception("FAIL: " + message);
}
