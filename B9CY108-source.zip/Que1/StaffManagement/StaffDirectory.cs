namespace StaffManagement;

public sealed class StaffDirectory
{
    private readonly List<Staff> _staff = [];

    public IReadOnlyList<Staff> AllStaff => _staff.AsReadOnly();

    public void Add(Staff member)
    {
        ArgumentNullException.ThrowIfNull(member);
        if (SearchStaff(member.StaffId))
            throw new InvalidOperationException($"Staff ID {member.StaffId} already exists.");
        _staff.Add(member);
    }

    // A binary result is required by the brief: true = found, false = absent.
    public bool SearchStaff(string staffId) =>
        !string.IsNullOrWhiteSpace(staffId) &&
        _staff.Any(member => string.Equals(member.StaffId, staffId.Trim(), StringComparison.OrdinalIgnoreCase));

    public Staff? FindStaff(string staffId) =>
        _staff.FirstOrDefault(member => string.Equals(member.StaffId, staffId.Trim(), StringComparison.OrdinalIgnoreCase));
}
