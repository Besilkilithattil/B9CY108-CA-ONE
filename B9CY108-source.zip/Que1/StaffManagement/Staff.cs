namespace StaffManagement;

public abstract class Staff
{
    private string _name;
    private string _department;

    protected Staff(string name, string staffId, string department)
    {
        _name = Required(name, nameof(name));
        StaffId = Required(staffId, nameof(staffId));
        _department = Required(department, nameof(department));
    }

    public string Name
    {
        get => _name;
        set => _name = Required(value, nameof(Name));
    }

    public string StaffId { get; }

    public string Department
    {
        get => _department;
        set => _department = Required(value, nameof(Department));
    }

    public abstract string Role { get; }
    public abstract string PerformDuty();

    public virtual string Describe() =>
        $"{StaffId} | {Name} | {Role} | {Department} | {PerformDuty()}";

    protected static string Required(string value, string field) =>
        string.IsNullOrWhiteSpace(value)
            ? throw new ArgumentException($"{field} cannot be blank.", field)
            : value.Trim();
}

public sealed class Doctor : Staff
{
    public Doctor(string name, string staffId, string department, string specialty)
        : base(name, staffId, department) => Specialty = Required(specialty, nameof(specialty));

    public string Specialty { get; }
    public override string Role => "Doctor";
    public override string PerformDuty() => $"Diagnoses and treats patients ({Specialty}).";
}

public sealed class Nurse : Staff
{
    public Nurse(string name, string staffId, string department, string shift)
        : base(name, staffId, department) => Shift = Required(shift, nameof(shift));

    public string Shift { get; }
    public override string Role => "Nurse";
    public override string PerformDuty() => $"Provides patient care ({Shift} shift).";
}

public sealed class AdministrativeStaff : Staff
{
    public AdministrativeStaff(string name, string staffId, string department, string officeRole)
        : base(name, staffId, department) => OfficeRole = Required(officeRole, nameof(officeRole));

    public string OfficeRole { get; }
    public override string Role => "Administrative Staff";
    public override string PerformDuty() => $"Coordinates hospital administration ({OfficeRole}).";
}
