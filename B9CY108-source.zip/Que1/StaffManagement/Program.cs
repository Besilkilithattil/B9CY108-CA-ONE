using StaffManagement;

var directory = new StaffDirectory();

while (true)
{
    Console.WriteLine("\n========================================");
    Console.WriteLine("STAFF MANAGEMENT");
    Console.WriteLine("========================================");
    Console.WriteLine("1. Add Doctor");
    Console.WriteLine("2. Add Nurse");
    Console.WriteLine("3. Add Administrative Staff");
    Console.WriteLine("4. Display All Staff");
    Console.WriteLine("5. Search Staff");
    Console.WriteLine("0. Exit");
    Console.Write("Choose an option: ");

    var choice = Console.ReadLine();
    if (choice is null or "0") break;

    try
    {
        switch (choice)
        {
            case "1":
            case "2":
            case "3":
                var name = ReadRequired("Name: ");
                var staffId = ReadRequired("Staff ID: ");
                var department = ReadRequired("Department: ");
                Staff member = choice switch
                {
                    "1" => new Doctor(name, staffId, department, ReadRequired("Specialty: ")),
                    "2" => new Nurse(name, staffId, department, ReadRequired("Shift: ")),
                    _ => new AdministrativeStaff(name, staffId, department, ReadRequired("Office role: "))
                };
                directory.Add(member);
                Console.WriteLine($"Added {member.Role}: {member.Name} ({member.StaffId}).");
                break;
            case "4":
                if (directory.AllStaff.Count == 0) Console.WriteLine("No staff recorded yet.");
                else foreach (var staff in directory.AllStaff) Console.WriteLine(staff.Describe());
                break;
            case "5":
                var searchId = ReadRequired("Enter staff ID: ");
                Console.WriteLine($"SearchStaff returned: {directory.SearchStaff(searchId)}");
                Console.WriteLine(directory.FindStaff(searchId)?.Describe() ?? "Staff member not found.");
                break;
            default:
                Console.WriteLine("Invalid option. Choose 0 to 5.");
                break;
        }
    }
    catch (ArgumentException error)
    {
        Console.WriteLine($"Input error: {error.Message}");
    }
    catch (InvalidOperationException error)
    {
        Console.WriteLine($"Cannot add staff: {error.Message}");
    }
}

static string ReadRequired(string prompt)
{
    Console.Write(prompt);
    var value = Console.ReadLine();
    if (string.IsNullOrWhiteSpace(value)) throw new ArgumentException("A value is required.");
    return value.Trim();
}
