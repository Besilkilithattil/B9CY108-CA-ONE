"""Scrape Dublin postal districts, then move JSON data to CSV and display it."""

import argparse
import csv
import json
import re
from pathlib import Path

import requests
from bs4 import BeautifulSoup, NavigableString, Tag

SOURCE_URL = "https://en.wikipedia.org/wiki/List_of_Dublin_postal_districts"
HEADING = re.compile(r"^Dublin\s+\d+(?:\s+West)?\s+\((D\d+W?)\)$")


def first_description(heading):
    for sibling in heading.parent.next_siblings:
        if isinstance(sibling, Tag) and sibling.select_one("h2"):
            break
        if isinstance(sibling, Tag) and sibling.name == "p" and "includes" in sibling.get_text(" ", strip=True):
            return sibling
    return None


def linked_area_names(paragraph, code):
    # The first descriptive sentence lists the areas. Later sentences often discuss
    # unrelated places, so stop at its first full stop.
    trigger = "takes in areas around" if code == "D2" else ("including" if code == "D1" else "includes")
    collecting = False
    areas = []
    for child in paragraph.children:
        if isinstance(child, NavigableString):
            words = str(child)
            if not collecting and trigger in words:
                collecting = True
                words = words.split(trigger, 1)[1]
            if collecting and "." in words:
                break
        elif isinstance(child, Tag) and collecting and child.name == "a":
            name = child.get_text(" ", strip=True)
            if name and not name.startswith("[") and name not in areas:
                areas.append(name)
    return areas


def extract_districts(html):
    soup = BeautifulSoup(html, "html.parser")
    districts = {}
    for heading in soup.select("h2"):
        match = HEADING.fullmatch(heading.get_text(" ", strip=True))
        if not match:
            continue
        code = match.group(1)
        paragraph = first_description(heading)
        if paragraph is None:
            raise ValueError(f"No area description found for {code}.")
        areas = linked_area_names(paragraph, code)
        if not areas:
            raise ValueError(f"No area names found for {code}.")
        districts[code] = areas
    if not districts:
        raise ValueError("No Dublin district headings were found; the page may have changed.")
    return districts


def main():
    parser = argparse.ArgumentParser(description="Scrape Dublin districts into JSON and CSV.")
    parser.add_argument("--html-file", type=Path, help="Use a saved copy of the source page for offline verification.")
    args = parser.parse_args()

    if args.html_file:
        html = args.html_file.read_text(encoding="utf-8")
        print(f"Reading saved webpage: {args.html_file.name}")
    else:
        response = requests.get(
            SOURCE_URL,
            headers={"User-Agent": "Mozilla/5.0 (compatible; B9CY108StudentResearch/1.0)"},
            timeout=20,
        )
        response.raise_for_status()
        html = response.text
        print(f"Fetched webpage: {SOURCE_URL}")

    districts = extract_districts(html)
    directory = Path(__file__).resolve().parent
    json_path = directory / "dublin_postal_districts.json"
    csv_path = directory / "dublin_postal_districts.csv"

    json_path.write_text(json.dumps(districts, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"Saved {len(districts)} districts to {json_path.name}")

    with json_path.open(encoding="utf-8") as source, csv_path.open("w", newline="", encoding="utf-8") as target:
        stored = json.load(source)
        writer = csv.writer(target)
        writer.writerow(["area_code", "area_name"])
        for code, names in stored.items():
            for name in names:
                writer.writerow([code, name])
    print(f"Moved JSON data to {csv_path.name}")

    print("\nDATA READ BACK FROM CSV")
    with csv_path.open(newline="", encoding="utf-8") as source:
        for row in csv.reader(source):
            print(f"{row[0]:<10} {row[1]}")


if __name__ == "__main__":
    main()
