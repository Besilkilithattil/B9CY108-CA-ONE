using System.Collections.Generic;

var students = BuildStudents();
Console.WriteLine($"STUDENT RECORD LOOKUP - {students.Count} records loaded");

while (true)
{
    Console.Write("\nEnter Student ID (or 0 to exit): ");
    var input = Console.ReadLine();
    if (input is null or "0") break;

    if (!int.TryParse(input, out var id))
    {
        Console.WriteLine("Please enter a numeric student ID.");
        continue;
    }

    if (!students.TryGetValue(id, out var student))
    {
        Console.WriteLine($"No student found for ID {id}.");
        continue;
    }

    Console.WriteLine($"Student ID: {student.Id}");
    Console.WriteLine($"Student Name: {student.Name}");
    foreach (var module in student.Modules)
        Console.WriteLine($"  {module.Name,-30} Marks: {module.Marks,3}  Grade: {module.Grade}");
}

static Dictionary<int, Student> BuildStudents()
{
    string[] names =
    [
        "Charles Severance", "Aisha Khan", "Daniel Murphy", "Sofia Walsh", "Liam Byrne",
        "Maya O'Brien", "Noah Kelly", "Chloe Ryan", "Adam Khan", "Emma Doyle",
        "Oscar Flynn", "Amira Ali", "Jack Nolan", "Ella McCarthy", "David Chen",
        "Grace O'Connor", "Ibrahim Hassan", "Hannah Clarke", "Leo Martin", "Zara Ahmed"
    ];
    string[] modules =
    [
        "Advanced Programming", "Advanced Databases", "Networking & Security",
        "Secure Software Development", "Research Methods"
    ];

    var result = new Dictionary<int, Student>();
    for (var i = 0; i < names.Length; i++)
    {
        var marks = i == 0
            ? new[] { 70, 65, 55, 72, 68 }
            : Enumerable.Range(0, modules.Length).Select(j => 50 + (i * 7 + j * 11) % 41).ToArray();
        var records = modules.Select((name, j) => new ModuleResult(name, marks[j], GradeFor(marks[j]))).ToArray();
        var student = new Student(20001010 + i, names[i], records);
        result.Add(student.Id, student);
    }
    return result;
}

static string GradeFor(int mark) => mark switch
{
    >= 80 => "A",
    >= 70 => "B+",
    >= 60 => "B",
    >= 50 => "C",
    >= 40 => "D",
    _ => "F"
};

internal sealed record ModuleResult(string Name, int Marks, string Grade);
internal sealed record Student(int Id, string Name, IReadOnlyList<ModuleResult> Modules);
